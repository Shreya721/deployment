# Amazon Product Related Queries App 💬

This app is an Review Sentiment Analysis and a LLM-powered chatbot for Amazon Product related queries.

## Deployment
Deployed to [streamlit](https://amaz0n-bot.streamlit.app/)
